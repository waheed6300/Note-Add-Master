package com.example.note_a;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class loginForm extends AppCompatActivity implements View.OnClickListener{

    MyDB Database;
    Button btnLogin;
    EditText email, password;
    String mail, pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_form);

        Database = new MyDB(this);
        btnLogin=(Button)findViewById(R.id.login);
        btnLogin.setOnClickListener(this);

        email=(EditText)findViewById(R.id.email_login);
        password=(EditText)findViewById(R.id.pass_login);
    }
    public void reg (View view) {
        Intent r = new Intent(this,RegistrationForm.class);
        startActivity(r);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.login:
                mail=email.getText().toString();
                pass=password.getText().toString();
//                Toast.makeText(this, "You entered email "+mail, Toast.LENGTH_LONG).show();
                boolean checkLogin = Database.validateUser(mail,pass);
                if (checkLogin == true){
                    Toast.makeText(this, "Welcome to Note Add Master App", Toast.LENGTH_LONG).show();
                }else {
                    Toast.makeText(this, "User not found, Incorrect Username or Password...!!", Toast.LENGTH_LONG).show();
                }
                break;
        }
    }
}
